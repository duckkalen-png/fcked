"""Build a named FreeCAD review assembly from the individual STEP files.

Run with: PYTHONPATH=/usr/lib/freecad-python3/lib /usr/bin/python3 make_freecad.py
The parametric source of the geometry is build_gimbal.py.
"""
import json
from pathlib import Path

import FreeCAD as App
import Part

root = Path(__file__).resolve().parent
data = json.loads((root / "assembly_manifest.json").read_text())
doc = App.newDocument("Gimbal_Concept")

groups = {}
names = {
    "structure": "Fixed_structure",
    "moving_structure": "Rotating_structure",
    "bearing": "Bearings_and_housings",
    "shaft": "Hollow_shafts_and_spacers",
    "mount": "Motor_and_camera_mounts",
    "placeholder": "Placeholder_envelopes",
    "fastener_detail": "Cable_details",
}

for family, group_name in names.items():
    group = doc.addObject("App::DocumentObjectGroup", group_name)
    group.Label = group_name.replace("_", " ")
    groups[family] = group

for part in data["parts"]:
    key = part["key"]
    shape = Part.Shape()
    shape.read(str(root / "parts_step" / (key + ".step")))
    if shape.isNull() or not shape.isValid():
        raise RuntimeError(f"Could not read valid STEP shape: {key}")
    obj = doc.addObject("Part::Feature", "P_" + key)
    obj.Label = part["label"]
    obj.Shape = shape
    obj.Placement.Base = App.Vector(*part["origin_mm"])
    obj.addProperty("App::PropertyString", "DesignStatus", "Concept metadata")
    obj.DesignStatus = part["status"]
    obj.addProperty("App::PropertyString", "DesignNote", "Concept metadata")
    obj.DesignNote = part["notes"]
    obj.addProperty("App::PropertyString", "SourceSTEP", "Concept metadata")
    obj.SourceSTEP = "parts_step/" + key + ".step"
    groups[part["family"]].addObject(obj)

doc.recompute()
path = root / "Gimbal_Review.FCStd"
doc.saveAs(str(path))
print("Saved", path, "with", len(data["parts"]), "named parts")
