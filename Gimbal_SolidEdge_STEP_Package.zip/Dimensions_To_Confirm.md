# Dimensions and interfaces to confirm

The current CAD is an image-derived concept. Supplying the entries below will let the major parts be remodeled to your actual project.

| Priority | Information | Why it changes the model |
| --- | --- | --- |
| 1 | One real overall dimension, ideally the fixed base plate diameter | Establishes scale for the whole image-derived assembly |
| 1 | Telescope mass, outer envelope, center-of-gravity location and required altitude-axis height | Determines fork spacing, trunnion location, balance and support loads |
| 1 | Required clear gap between fork inner faces and telescope body | Sets the cylindrical spacer lengths and arm spacing |
| 1 | Camera and derotator make/model, size, interface bolt pattern and optical clear aperture | Sets the Nasmyth-side adapter and camera plate |
| 1 | Altitude and azimuth motors/gearboxes: vendor model, flange pattern, shaft size and required torque | Sets both motor mounts, coupler and drive layout |
| 1 | Altitude and azimuth bearing model or required bore/outer diameter/width | Sets trunnions, cartridges, housing and fits |
| 2 | Required altitude travel and azimuth travel, plus cable routing and cable bend radius | Defines hard stops, cable passages and clip positions |
| 2 | Environment, pointing accuracy, vibration and shock requirements | Enables stiffness, backlash, thermal and structural analysis |
| 2 | Material and manufacture preference for base, arms and shafts | Changes wall thickness, ribs, joining methods and tolerances |
| 2 | Real foundation bolt circle and fastener sizes | Finalizes base plate and mounting bracket holes |

If only rough measurements are available, mark them approximate. A front, side and top view with one dimension each would remove much of the ambiguity in the current perspective image.
