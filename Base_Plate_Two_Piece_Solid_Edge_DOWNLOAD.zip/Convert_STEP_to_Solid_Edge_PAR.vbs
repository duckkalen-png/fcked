Option Explicit

' Run by double-clicking this file on a Windows PC with Solid Edge installed.
' It opens the two STEP files in this folder and saves each as a native .par.

Dim fso, folder, app, names, partName, stepPath, parPath, doc
Set fso = CreateObject("Scripting.FileSystemObject")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
names = Array("01_bottom_mounting_plate", "02_upright_with_top_cap")

Set app = CreateObject("SolidEdge.Application")
app.Visible = True

For Each partName In names
    stepPath = fso.BuildPath(folder, partName & ".step")
    parPath = fso.BuildPath(folder, partName & ".par")

    If Not fso.FileExists(stepPath) Then
        Err.Raise vbObjectError + 1, , "Missing STEP file: " & stepPath
    End If
    If fso.FileExists(parPath) Then
        Err.Raise vbObjectError + 2, , "PAR file already exists; move it before rerunning: " & parPath
    End If

    Set doc = app.Documents.Open(stepPath)
    doc.SaveAs parPath
    doc.Close
    Set doc = Nothing
Next

WScript.Echo "Saved both Solid Edge .par files in: " & folder
