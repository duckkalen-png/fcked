# Base plate split into two parts

The supplied `base_plate_gpt.stp` was split at its plate-to-upright seam, at source-coordinate **Y = 0 mm**. The small top cap remains connected to the upright, as requested. Both pieces retain their original coordinates and fit together without repositioning.

| File | Contents | Volume |
| --- | --- | ---: |
| `01_bottom_mounting_plate.step` | Bottom mounting plate, Y = -6 to 0 mm | 2675.049793 mm³ |
| `02_upright_with_top_cap.step` | Upright and top cap, Y = 0 to 23 mm | 1167.026830 mm³ |
| `Two_Piece_Assembly.step` | Both solids, aligned as in the source | 3842.076622 mm³ |

`Split_Preview.png` shows the assembled and separated pieces. `split_dimensions.csv` gives each bounding box and volume.

## Create native Solid Edge `.par` files

This package contains accurate STEP solids. On a Windows computer with Solid Edge installed, keep the two `.step` files and `Convert_STEP_to_Solid_Edge_PAR.vbs` in the same folder, then double-click the `.vbs` file. It opens each STEP file in Solid Edge and saves `01_bottom_mounting_plate.par` and `02_upright_with_top_cap.par` beside them. If Solid Edge shows import options, accept the solid-body import. Existing `.par` files are protected against overwrite.

The conversion script has not been run here because Solid Edge is unavailable in this cloud environment. You can also open each `.step` file manually in Solid Edge and use **Save As → Solid Edge Part (`.par`)**.

## Geometry check

Both STEP pieces were reimported as valid single solids; the assembly reimported as two valid solids. Their volumes sum to the supplied source volume within 0.000001 mm³. Their intersection volume is zero.
