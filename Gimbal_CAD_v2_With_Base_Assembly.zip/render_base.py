"""Create assembled/exploded base views and a readable PDF fit-up guide."""
from pathlib import Path
import json
import re

import cadquery as cq
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

from reportlab.platypus import SimpleDocTemplate, Image, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

P=Path(__file__).resolve().parent
manifest=json.loads((P/'assembly_manifest.json').read_text())
index={q['key']:q for q in manifest['parts']}
order=json.loads((P/'base_selected.json').read_text())
palette={'structure':'#bcc5cb','moving_structure':'#8fa8b4','bearing':'#485f6e',
         'shaft':'#688ca1','mount':'#d5a554','placeholder':'#35424b'}

explode={
 '01_fixed_base_plate':(0,0,-85), '02_az_bearing_housing':(0,0,-58),
 '03_az_bearing_envelope':(0,0,-25), '04_az_hollow_shaft':(-150,0,0),
 '31_az_shaft_hub':(0,0,20), '05_az_drive_ring':(0,0,60),
 '06_az_rotating_turntable':(0,0,105), '07_rotating_base_deck':(0,0,165),
 '26_az_motor_mount':(140,-40,-40), '27_az_motor_envelope':(140,-40,-90),
 '28_az_pinion_blank':(140,-40,-15),
}

triangles={}
for key in order:
    q=index[key]
    shape=cq.importers.importStep(str(P/'parts_step'/(key+'.step'))).val()
    pts,faces=shape.tessellate(2.5)
    arr=np.array([[p.x,p.y,p.z] for p in pts],dtype=float)
    arr+=np.array(q['origin_mm'])
    triangles[key]=arr[np.array(faces,dtype=int)]

fig=plt.figure(figsize=(16,9),facecolor='#f5f7f7')
fig.text(.025,.96,'BASE AND AZIMUTH DRIVE · ASSEMBLY 1',
         fontsize=21,fontweight='bold',color='#173443')
fig.text(.025,.918,'Eleven named parts, including four provisional envelopes/blanks. Exploded offsets show order only.',
         fontsize=11,color='#596f7a')
for k,(heading,shifted) in enumerate([('ASSEMBLED POSITION',False),('EXPLODED ORDER',True)]):
    ax=fig.add_axes([.025+k*.48,.15,.47,.71],projection='3d',proj_type='ortho')
    for key in order:
        part=index[key]
        faces=triangles[key]+(np.array(explode[key]) if shifted else 0)
        coll=Poly3DCollection(faces,facecolors=palette[part['family']],
                              edgecolors='none',linewidths=0,
                              alpha=.47 if part['status']=='placeholder envelope' else 1,
                              zsort='average')
        ax.add_collection3d(coll)
    ax.set(xlim=(-370,450),ylim=(-370,310),zlim=(-170,340))
    ax.set_box_aspect((820,680,510),zoom=.9)
    ax.view_init(elev=24,azim=-65)
    ax.set_axis_off()
    fig.text(.04+k*.48,.875,heading,fontsize=14,fontweight='bold',color='#007f7b')
fig.text(.028,.095,'Fixed support: 01 → 02 → 03   •   Rotating stack: 04 → 31 → 05 → 06 → 07   •   Drive: 26 → 27 → 28',
         fontsize=11,color='#173443')
fig.text(.028,.058,'All dimensions are provisional millimetres. Bearing, motor, gear teeth and torque connection require selected hardware.',
         fontsize=9,color='#a45c24')
fig.savefig(P/'Base_Exploded_View.png',dpi=170,facecolor=fig.get_facecolor())
plt.close(fig)

pdfmetrics.registerFont(TTFont('DV','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('DV-Bold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
pdfmetrics.registerFontFamily('DV',normal='DV',bold='DV-Bold',italic='DV',boldItalic='DV-Bold')
sty=getSampleStyleSheet()
sty.add(ParagraphStyle(name='MainCAD',fontName='DV-Bold',fontSize=17,leading=22,
                       textColor=HexColor('#173443'),spaceAfter=12))
sty.add(ParagraphStyle(name='HeadCAD',fontName='DV-Bold',fontSize=13,leading=17,
                       textColor=HexColor('#007f7b'),spaceBefore=12,spaceAfter=7,keepWithNext=True))
sty.add(ParagraphStyle(name='BodyCAD',fontName='DV',fontSize=9.2,leading=14.2,
                       textColor=HexColor('#173443'),spaceAfter=7))
sty.add(ParagraphStyle(name='CellCAD',fontName='DV',fontSize=8.2,leading=12,
                       textColor=HexColor('#173443')))

story=[Paragraph('Base and azimuth drive: virtual fit-up',sty['MainCAD']),
       Paragraph('The assembled view shows the saved component positions. The exploded view separates the pieces to show their order; its offsets are illustrative.',sty['BodyCAD'])]
im=Image(str(P/'Base_Exploded_View.png'),width=landscape(A4)[0]-68,
         height=(landscape(A4)[0]-68)*9/16)
story+=[im,Spacer(1,10),Paragraph('Source: image-derived concept model. Eleven named STEP parts. Dimensions are provisional millimetres.',sty['BodyCAD']),PageBreak()]

story.extend([
    Paragraph('How the parts stack on the azimuth axis',sty['MainCAD']),
    Paragraph('This section passes through the azimuth axis and the motor location. Its colours and geometry explain the interfaces; it is not a manufacturing drawing.',sty['BodyCAD']),
    Image(str(P/'Base_Axial_Section.png'),width=landscape(A4)[0]-68,
          height=(landscape(A4)[0]-68)/2),
    Spacer(1,10),
    Paragraph('Read from bottom to top: fixed plate 01, bearing housing 02 and bearing envelope 03, rotating hub 31 and drive ring 05, turntable 06, then fork deck 07. The hollow shaft 04 passes through the centre.',sty['BodyCAD']),
    PageBreak(),
])

raw=(P/'Base_Assembly_Guide.md').read_text()
story.append(Paragraph('Parts and suggested assembly order',sty['MainCAD']))
lines=raw.splitlines();i=0
while i<len(lines):
    t=lines[i].strip();i+=1
    if not t:continue
    if t.startswith('# '):continue
    if t.startswith('## '):
        story.append(Paragraph(t[3:],sty['HeadCAD']));continue
    if t.startswith('|'):
        rows=[t]
        while i<len(lines) and lines[i].lstrip().startswith('|'):
            rows.append(lines[i]);i+=1
        table=[]
        for row in rows:
            cells=[x.strip() for x in row.strip().strip('|').split('|')]
            if all(re.fullmatch(r':?-+:?',x.replace(' ','')) for x in cells):continue
            table.append([Paragraph(c,sty['CellCAD']) for c in cells])
        tb=Table(table,colWidths=[90,94,landscape(A4)[0]-68-184],repeatRows=1)
        tb.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#e1f1eb')),
                                ('ROWBACKGROUNDS',(0,1),(-1,-1),[HexColor('#f7f8f5'),HexColor('#ffffff')]),
                                ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),
                                ('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),5),
                                ('BOTTOMPADDING',(0,0),(-1,-1),5)]))
        story.extend([tb,Spacer(1,9)]);continue
    if t[0].isdigit() and '. ' in t[:4]:
        t='• '+t
    t=t.replace('**','').replace('`','')
    story.append(Paragraph(t,sty['BodyCAD']))

doc=SimpleDocTemplate(str(P/'Base_Assembly_Guide.pdf'),pagesize=landscape(A4),
                      leftMargin=34,rightMargin=34,topMargin=30,bottomMargin=35,
                      title='Base and azimuth drive: virtual fit-up')
doc.build(story)
print('Rendered base exploded view and PDF guide')
