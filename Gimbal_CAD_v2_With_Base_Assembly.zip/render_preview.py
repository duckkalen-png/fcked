"""Render review-only views from the exported STEP parts (not manufacturing drawings)."""
from pathlib import Path
import json
import numpy as np
import cadquery as cq
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

ROOT=Path(__file__).resolve().parent
meta=json.loads((ROOT/'assembly_manifest.json').read_text())
palette={
 'structure':'#b9c1c8', 'moving_structure':'#9facb8',
 'bearing':'#495e6d','shaft':'#64859a','mount':'#ceaa67',
 'placeholder':'#39434b','fastener_detail':'#7c979d'}

def load_triangles():
    grouped={k:[] for k in palette}
    for item in meta['parts']:
        shape=cq.importers.importStep(str(ROOT/'parts_step'/(item['key']+'.step'))).val()
        vertices, faces=shape.tessellate(2.5)
        pts=np.array([[v.x,v.y,v.z] for v in vertices],dtype=float)
        pts+=np.array(item['origin_mm'])
        grouped[item['family']].append(pts[np.array(faces,dtype=int)])
    return {k:np.concatenate(v,axis=0) for k,v in grouped.items() if v}

meshes=load_triangles()

legend=[
 ('01','Fixed base + az bearing'),('05','Azimuth drive ring'),
 ('07','Rotating base deck'),('08/09','Separate fork arms'),
 ('12/13','Altitude bearings'),('14/15','Hollow trunnions'),
 ('16/17','Cylindrical spacers'),('18','Telescope envelope'),
 ('19–22','Derotator + camera mount'),('23–25','Altitude motor + mount'),
 ('26–28','Azimuth motor + mount'),('29/30','Cable clips')]

def render(name,elev,azim):
    fig=plt.figure(figsize=(15,10),facecolor='#f5f7f7')
    ax=fig.add_axes([.02,.04,.72,.9],projection='3d',facecolor='#f5f7f7',proj_type='ortho')
    for family,triangles in meshes.items():
        coll=Poly3DCollection(triangles,facecolors=palette[family],edgecolors='none',
                              linewidths=0,alpha=.38 if family=='placeholder' else 1,
                              zsort='average')
        ax.add_collection3d(coll)
    ax.set(xlim=(-365,315),ylim=(-280,250),zlim=(-100,440))
    ax.set_box_aspect((680,530,540),zoom=.88)
    ax.view_init(elev=elev,azim=azim)
    ax.set_axis_off()
    fig.text(.035,.94,'TWO-AXIS FORK GIMBAL · CONCEPT MODEL',fontsize=19,
             fontweight='bold',color='#173443')
    fig.text(.035,.91,'Image-derived proportions; dimensions are provisional millimetres',
             fontsize=10,color='#596f7a')
    fig.text(.755,.86,'Part groups',fontsize=15,fontweight='bold',color='#173443')
    for i,(n,label) in enumerate(legend):
        y=.82-i*.057
        fig.text(.755,y,n,fontsize=11,fontweight='bold',color='#007f7b')
        fig.text(.81,y,label,fontsize=10,color='#173443')
    fig.text(.755,.075,f"{len(meta['parts'])} separate STEP parts\n1 named STEP assembly\nFreeCAD review assembly",
             fontsize=11,color='#173443',linespacing=1.5)
    fig.text(.035,.035,'Not production-ready: verify loads, fits, materials, motors, cables and hole patterns.',
             fontsize=9,color='#a45c24')
    fig.savefig(ROOT/name,dpi=170,facecolor=fig.get_facecolor())
    plt.close(fig)
    print(name)

render('Gimbal_Isometric_Preview.png',23,-65)
render('Gimbal_Front_Preview.png',7,-90)

selected=[1,8,9,14,16,19,23,26]
fig=plt.figure(figsize=(16,9),facecolor='#f5f7f7')
fig.suptitle('KEY PARTS · SEPARATE STEP FILES',x=.04,y=.98,ha='left',
             fontsize=21,fontweight='bold',color='#173443')
for j,num in enumerate(selected):
    item=meta['parts'][num-1]
    shape=cq.importers.importStep(str(ROOT/'parts_step'/(item['key']+'.step'))).val()
    vv,ff=shape.tessellate(2.5)
    vertices=np.array([[v.x,v.y,v.z] for v in vv])
    triangles=vertices[np.array(ff,dtype=int)]
    ax=fig.add_subplot(2,4,j+1,projection='3d',proj_type='ortho')
    ax.add_collection3d(Poly3DCollection(triangles,
                            facecolors=palette[item['family']],edgecolors='none',
                            zsort='average'))
    ext=np.array(item['bbox_mm'])
    lim=max(ext)*.64
    ax.set(xlim=(-lim,lim),ylim=(-lim,lim),zlim=(-lim,lim))
    ax.set_box_aspect((1,1,1),zoom=1.15)
    ax.view_init(elev=25,azim=-62)
    ax.set_axis_off()
    ax.set_title(f"{num:02d}  {item['label']}",fontsize=11,
                 fontweight='bold',color='#173443',pad=4)
    dims=' × '.join(f"{x:.0f}" for x in ext)
    ax.text2D(.5,-.06,dims+' mm bounding size',transform=ax.transAxes,
              ha='center',fontsize=8,color='#596f7a')
fig.text(.04,.02,f"Provisional concept geometry. See Parts_List.csv for all {len(meta['parts'])} parts and assumptions.",
         fontsize=10,color='#a45c24')
fig.subplots_adjust(left=.015,right=.985,bottom=.065,top=.91,wspace=.02,hspace=.24)
fig.savefig(ROOT/'Gimbal_Key_Parts.png',dpi=160,facecolor=fig.get_facecolor())
plt.close(fig)
print('Gimbal_Key_Parts.png')
