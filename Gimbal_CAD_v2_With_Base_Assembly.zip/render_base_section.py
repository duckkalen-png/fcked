"""Draw an original axial-section teaching schematic of the provisional base."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

P=Path(__file__).resolve().parent
fig,ax=plt.subplots(figsize=(16,8),facecolor='#f6f8f8')
ax.set_facecolor('#ffffff')

cols={'fixed':'#bfc7cd','bearing':'#496c80','shaft':'#5e91a2',
      'rotor':'#8cadb9','gear':'#d3ac67','motor':'#414d55',
      'hub':'#008781'}

def band(x1,x2,z1,z2,color):
    ax.add_patch(Rectangle((x1,z1),x2-x1,z2-z1,
                           facecolor=color,edgecolor='#233846',linewidth=.8))

def pair(r1,r2,z1,z2,color):
    band(-r2,-r1,z1,z2,color);band(r1,r2,z1,z2,color)

# Section approximates solids in a plane through the azimuth motor axis.
band(-250,250,0,18,cols['fixed'])                         # 01
band(-38,38,0,18,'#ffffff')                               # central passage
band(192,216,0,18,'#ffffff')                             # motor passage
pair(155,194,18,40,cols['fixed'])                        # 02
pair(116,155,22,53,cols['bearing'])                      # 03
pair(17,37,-37,69,cols['shaft'])                         # 04 hollow shaft
pair(37.1,75,41,53,cols['hub'])                          # 31 hub
pair(160,187,42,53,cols['gear'])                         # 05 gear ring
pair(38,192,53,68,cols['rotor'])                         # 06
pair(38,189,68,110,cols['rotor'])                        # 07
band(159,249,-13,0,cols['gear'])                         # 26 bracket
band(169,239,-77,-15,cols['motor'])                      # 27 motor
band(194,214,-15,43,cols['motor'])                       # 28 shaft
band(188,220,43,53,cols['motor'])                       # 28 blank

ax.plot([0,0],[-90,130],color='#ef6b4d',lw=1.6,ls='--')
ax.text(3,123,'azimuth rotation axis',fontsize=11,color='#d4573b')
ax.annotate('',xy=(0,115),xytext=(0,98),arrowprops=dict(arrowstyle='-|>',color='#d4573b',lw=2))
ax.text(-188,117,'Next region: fork feet attach to deck',fontsize=10,color='#295460')

left=[
 ('07 · rotating fork deck',-189,100),('06 · turntable',-192,63),
 ('05 · drive ring blank',-187,47),('31 · shaft hub blank',-75,46),
 ('03 · bearing envelope',-155,27),('02 · fixed housing',-194,13),
 ('01 · fixed base plate',-250,-5),('04 · hollow shaft',-37,-43),
]
for label,x,z in left:
    ax.annotate(label,xy=(x,z),xytext=(-305,z+5 if 'hub' in label else z),
                fontsize=9.5,ha='left',va='center',color='#183744',
                arrowprops=dict(arrowstyle='-',lw=.9,color='#61808a'))
right=[('28 · plain pinion blank',219,58),('26 · motor bracket',240,-3),
       ('27 · motor envelope',238,-64)]
for label,x,z in right:
    ax.annotate(label,xy=(x,z),xytext=(260,z),fontsize=9.5,va='center',
                color='#183744',arrowprops=dict(arrowstyle='-',lw=.9,color='#61808a'))

ax.set_xlim(-315,375);ax.set_ylim(-92,140)
ax.set_xlabel('Radial location across a plane through the motor axis (mm)',fontsize=10)
ax.set_ylabel('Height Z (mm)',fontsize=10)
ax.set_yticks([-77,-37,0,18,40,53,68,110])
ax.grid(axis='y',alpha=.2)
ax.set_aspect('auto')
for side in ['top','right']:ax.spines[side].set_visible(False)
fig.suptitle('BASE SUBASSEMBLY · SCHEMATIC AXIAL SECTION',x=.055,ha='left',
             fontsize=20,fontweight='bold',color='#173443')
fig.text(.055,.905,'Part numbers map to the STEP files. Colours identify interfaces; the section is simplified for explanation.',
         fontsize=10,color='#596f7a')
fig.text(.055,.035,'The bearing and motor are envelopes. Gear teeth, fasteners, bearing preload and shaft-to-hub torque connection are not designed.',
         fontsize=9,color='#a45c24')
fig.subplots_adjust(left=.08,right=.96,bottom=.14,top=.86)
fig.savefig(P/'Base_Axial_Section.png',dpi=170,facecolor=fig.get_facecolor())
plt.close(fig)
print('Base_Axial_Section.png')
