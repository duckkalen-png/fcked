"""Parametric, image-derived concept model of a two-axis fork gimbal.

Run: python3 build_gimbal.py
All dimensions are provisional millimetres. No structural, bearing, or motor
sizing is implied. Individual STEP parts use a practical local origin; assembly
STEP/FCStd restore each part to its global position.
"""

from __future__ import annotations

from pathlib import Path
import csv
import json
import math
import subprocess

import cadquery as cq
from cadquery import exporters

ROOT = Path(__file__).resolve().parent
PARTS = ROOT / "parts_step"
PARTS.mkdir(exist_ok=True)

P = {
    "unit": "mm",
    "base_diameter": 500.0,
    "base_thickness": 18.0,
    "base_bolt_circle_diameter": 460.0,
    "base_bolt_count": 12,
    "base_bolt_hole_diameter": 9.0,
    "az_outer_bearing_diameter": 388.0,
    "az_inner_bearing_diameter": 312.0,
    "az_axis_shaft_diameter": 74.0,
    "deck_width_x": 378.0,
    "deck_depth_y": 250.0,
    "deck_top_z": 110.0,
    "fork_axis_x": 154.0,
    "fork_thickness_x": 36.0,
    "altitude_axis_z": 352.0,
    "fork_bearing_bore_diameter": 82.0,
    "trunnion_outer_diameter": 60.0,
    "trunnion_hollow_bore_diameter": 34.0,
    "telescope_envelope_x": 170.0,
    "telescope_envelope_y": 155.0,
    "telescope_envelope_z": 120.0,
    "camera_envelope_x": 78.0,
    "camera_envelope_y": 94.0,
    "camera_envelope_z": 92.0,
    "az_motor_envelope_diameter": 70.0,
    "alt_motor_envelope_diameter": 82.0,
}

Z = P["altitude_axis_z"]
COMPONENTS: list[dict] = []

COLORS = {
    "structure": (0.71, 0.75, 0.79),
    "moving_structure": (0.61, 0.67, 0.73),
    "bearing": (0.27, 0.38, 0.46),
    "shaft": (0.37, 0.51, 0.59),
    "mount": (0.80, 0.65, 0.37),
    "placeholder": (0.20, 0.26, 0.32),
    "fastener_detail": (0.49, 0.58, 0.62),
}


def cyl_z(radius, z0, height, x=0, y=0):
    return cq.Workplane("XY").workplane(offset=z0).center(x, y).circle(radius).extrude(height)


def ring_z(ro, ri, z0, height, x=0, y=0):
    return cq.Workplane("XY").workplane(offset=z0).center(x, y).circle(ro).circle(ri).extrude(height)


def cyl_x(radius, x0, length, y=0, z=Z):
    return cq.Workplane("YZ", origin=(x0, y, z)).circle(radius).extrude(length)


def ring_x(ro, ri, x0, length, y=0, z=Z):
    return cq.Workplane("YZ", origin=(x0, y, z)).circle(ro).circle(ri).extrude(length)


def box(xlen, ylen, zlen, x=0, y=0, z=0):
    return cq.Workplane("XY").box(xlen, ylen, zlen).translate((x, y, z))


def bores_z(shape, points, radius, z0, length):
    for x, y in points:
        shape = shape.cut(cyl_z(radius, z0, length, x, y))
    return shape


def bolt_circle_xy(radius, count, phase_deg=0):
    return [(radius * math.cos(math.radians(phase_deg + i * 360 / count)),
             radius * math.sin(math.radians(phase_deg + i * 360 / count)))
            for i in range(count)]


def bolt_circle_yz(radius, count, phase_deg=45):
    return [(radius * math.cos(math.radians(phase_deg + i * 360 / count)),
             radius * math.sin(math.radians(phase_deg + i * 360 / count)))
            for i in range(count)]


def bores_x(shape, yz_points, hole_r, x0, length, z_origin=Z):
    for y, dz in yz_points:
        shape = shape.cut(cyl_x(hole_r, x0, length, y, z_origin + dz))
    return shape


def add(key, label, shape, family, status="concept hardware", notes=""):
    solid = shape.val() if isinstance(shape, cq.Workplane) else shape
    if not solid.isValid():
        raise ValueError(f"Invalid solid: {key}")
    bb = solid.BoundingBox()
    # Set a useful local coordinate datum, then restore it in the assembly.
    origin = ((bb.xmin + bb.xmax) / 2, (bb.ymin + bb.ymax) / 2,
              (bb.zmin + bb.zmax) / 2)
    local = solid.translate(cq.Vector(*(-v for v in origin)))
    out = PARTS / f"{key}.step"
    exporters.export(local, str(out), exportType="STEP")
    COMPONENTS.append({"key": key, "label": label, "family": family,
                       "status": status, "notes": notes, "origin_mm": origin,
                       "shape": solid, "local": local, "step": out,
                       "volume_mm3": solid.Volume(),
                       "bbox_mm": (bb.xlen, bb.ylen, bb.zlen)})


# Fixed azimuth foundation: flange, bolt circle, coaxial bearing seat and drive.
plate = cyl_z(P["base_diameter"] / 2, 0, P["base_thickness"])
plate = bores_z(plate, bolt_circle_xy(P["base_bolt_circle_diameter"] / 2,
                                      P["base_bolt_count"], 15),
                P["base_bolt_hole_diameter"] / 2, -1, 20)
plate = plate.cut(cyl_z(P["az_axis_shaft_diameter"] / 2 + 1, -1, 20))
plate = plate.cut(cyl_z(12, -1, 20, 120, -165))
az_mount_holes = [(x, y) for x in (90, 150) for y in (-190, -140)]
plate = bores_z(plate, az_mount_holes, 4.5, -1, 20)
az_housing_holes = bolt_circle_xy(175, 8, 22.5)
plate = bores_z(plate, az_housing_holes, 5.0, -1, 20)
add("01_fixed_base_plate", "Fixed circular base plate", plate, "structure",
    notes="Ø500 x 18; twelve Ø9 anchor holes on Ø460 PCD; eight Ø10 housing holes on Ø350 PCD; centre and drive-shaft bores.")

az_housing = ring_z(194, 155, 18, 22)
az_housing = bores_z(az_housing, az_housing_holes, 5, 17, 24)
add("02_az_bearing_housing", "Azimuth bearing housing ring", az_housing,
    "bearing", notes="Eight Ø10 holes align with base; nominal Ø310 bearing seat. Actual bearing fit unspecified.")

az_bearing = ring_z(155, 116, 22, 31)
add("03_az_bearing_envelope", "Azimuth bearing race envelope", az_bearing,
    "bearing", status="placeholder envelope",
    notes="Simplified Ø310 annulus spans housing and underside of turntable; rolling elements and fits not modeled.")

shaft = cyl_z(P["az_axis_shaft_diameter"] / 2, -37, 106).cut(cyl_z(17, -38, 108))
add("04_az_hollow_shaft", "Hollow azimuth shaft", shaft, "shaft",
    notes="Ø74 hollow concept shaft; no bearing shoulder or verified cable allowance.")

drive_ring = ring_z(187, 160, 42, 11)
drive_ring = bores_z(drive_ring, bolt_circle_xy(174, 8, 22.5), 5, 41, 13)
add("05_az_drive_ring", "Azimuth drive ring blank", drive_ring,
    "moving_structure", notes="Eight Ø10 mating holes align with turntable; no gear teeth or drive ratio assigned.")

turntable = cyl_z(192, 53, 15).cut(cyl_z(38, 52, 18))
turntable = bores_z(turntable, bolt_circle_xy(174, 8, 22.5), 5, 52, 17)
deck_mount_holes = [(x, y) for x in (-130, 130) for y in (-90, 90)]
turntable = bores_z(turntable, deck_mount_holes, 4.5, 52, 17)
turntable = bores_z(turntable, bolt_circle_xy(60, 6), 4.0, 52, 17)
add("06_az_rotating_turntable", "Azimuth rotating turntable", turntable,
    "moving_structure", notes="Matches drive ring, hub and four deck holes; mating patterns remain provisional.")

deck = box(P["deck_width_x"], P["deck_depth_y"], 42, 0, 0, 89)
feet_holes = [(x, y) for x in (-154, 154) for y in (-55, 55)]
deck = bores_z(deck, feet_holes, 4.5, 67, 44)
deck = bores_z(deck, deck_mount_holes, 4.5, 67, 44)
deck = deck.cut(cyl_z(38, 67, 44))
add("07_rotating_base_deck", "Rectangular rotating base deck", deck,
    "moving_structure", notes="378 x 250 x 42; four fork foot holes, four aligned turntable holes, axial cable bore.")


def fork(side):
    xc = side * P["fork_axis_x"]
    # A genuine three-dimensional tapered tower: wide foot, narrower y and x
    # section at the altitude bearing. Left and right are independent parts.
    arm = (cq.Workplane("XY").workplane(offset=110).center(xc, 0).rect(70, 176)
           .workplane(offset=125).rect(56, 118)
           .workplane(offset=117).rect(46, 110).loft(combine=True))
    arm = arm.union(cyl_x(68, xc - 23, 46))
    arm = arm.cut(cyl_x(P["fork_bearing_bore_diameter"] / 2, xc - 36, 72))
    arm = bores_x(arm, bolt_circle_yz(55, 4), 4.0, xc - 36, 72)
    arm = bores_z(arm, [(xc, -55), (xc, 55)], 4.5, 109, 33)
    if side < 0:
        # Separate cable saddle mounting holes on the left arm.
        arm = bores_x(arm, [(-64, -131), (-64, -174)], 3.3, xc - 36, 72)
    return arm


add("08_left_fork_arm", "Left fork arm with cable saddle holes", fork(-1),
    "moving_structure", notes="Separate left-hand part; Ø82 bearing bore; four Ø8 flange holes.")
add("09_right_fork_arm", "Right fork arm", fork(1),
    "moving_structure", notes="Separate right-hand part; Ø82 bearing bore; four Ø8 flange holes.")

for side, key, label in [(-1, "10_left_gusset", "Left inner fork gusset"),
                         (1, "11_right_gusset", "Right inner fork gusset")]:
    x = side * 113
    gus = (cq.Workplane("YZ", origin=(x - 6, 0, 0))
           .polyline([(-68, 111), (4, 111), (-46, 231)]).close().extrude(12))
    add(key, label, gus, "moving_structure", notes="Concept reinforcing web; join method unspecified.")


# Bearing cartridges in the fork holes; trunnions pass through them.
for side, prefix, idx in [(-1, "left", 12), (1, "right", 13)]:
    xc = side * P["fork_axis_x"]
    bearing = ring_x(40.0, 30.5, xc - 15, 30)
    add(f"{idx:02d}_{prefix}_alt_bearing", f"{prefix.title()} altitude bearing cartridge",
        bearing, "bearing", status="placeholder envelope",
        notes="Ø80 outside / Ø61 inside annulus, 30 wide; select real bearing and fits.")

for side, prefix, idx in [(-1, "left", 14), (1, "right", 15)]:
    x0 = -189 if side < 0 else 82
    shaft = ring_x(30, 17, x0, 107 if side < 0 else 136)
    add(f"{idx:02d}_{prefix}_hollow_trunnion", f"{prefix.title()} hollow trunnion",
        shaft, "shaft", notes="Ø60 / Ø34 hollow axle; right shaft extends to drive coupler; fits unverified.")

for side, prefix, idx in [(-1, "left", 16), (1, "right", 17)]:
    x0 = -131 if side < 0 else 87
    spacer = ring_x(39, 30.6, x0, 44)
    add(f"{idx:02d}_{prefix}_trunnion_spacer", f"{prefix.title()} trunnion spacer collar",
        spacer, "shaft", notes="Cylindrical standoff between payload and fork bearing; clearance illustrative.")

cradle = box(174, P["telescope_envelope_y"],
             P["telescope_envelope_z"], 0, 0, Z)
cradle = cradle.cut(cyl_x(30.5, -88, 176))
add("18_telescope_cradle_envelope", "Telescope optical body envelope", cradle,
    "placeholder", status="placeholder envelope",
    notes="Block represents telescope payload only; no optics or tube prescription supplied.")

# Nasmyth-side circular connection, derotator envelope and camera interface.
cam_adapter = ring_x(49, 18, -199, 10)
cam_adapter = bores_x(cam_adapter, bolt_circle_yz(40, 6, 0), 3.5, -200, 12)
add("19_camera_mount_adapter", "Nasmyth camera mount adapter flange",
    cam_adapter, "mount", notes="Six Ø7 through-holes on Ø80 PCD; camera standard unassigned.")

derotator = ring_x(43, 20, -257, 58)
add("20_derotator_envelope", "Derotator housing envelope", derotator,
    "placeholder", status="placeholder envelope",
    notes="Geometry only: no bearings, optical path, drive or camera rotation spec.")

camera_plate = box(10, 100, 100, -262, 0, Z).cut(cyl_x(20, -268, 12))
camera_plate = bores_x(camera_plate, bolt_circle_yz(43, 4), 3.5, -268, 12)
add("21_camera_interface_plate", "Camera interface plate", camera_plate,
    "mount", notes="Square camera mounting plate; pattern and aperture provisional.")

camera = box(P["camera_envelope_x"], P["camera_envelope_y"],
             P["camera_envelope_z"], -306, 0, Z)
add("22_camera_envelope", "Camera body envelope", camera, "placeholder",
    status="placeholder envelope", notes="Camera size only; no sensor, service or cable features.")

# Right-side altitude motor support and drive elements.
motor_plate = ring_x(76, 34, 181, 15)
motor_plate = bores_x(motor_plate, bolt_circle_yz(55, 4), 4.5, 180, 17)
add("23_alt_motor_mount", "Altitude motor mounting plate", motor_plate,
    "mount", notes="Ø152 plate with Ø68 opening and four Ø9 through-holes.")

coupling = ring_x(42, 30.5, 196, 22)
add("24_alt_motor_coupler_envelope", "Altitude motor coupling envelope",
    coupling, "placeholder", status="placeholder envelope",
    notes="Motor and shaft connection not engineered; envelope only.")

alt_motor = cyl_x(P["alt_motor_envelope_diameter"] / 2, 218, 72)
add("25_alt_motor_envelope", "Altitude drive motor envelope", alt_motor,
    "placeholder", status="placeholder envelope",
    notes="Motor torque, gearbox, bearings and exact bolt pattern not selected.")

# Azimuth drive suspended under the fixed base. The cutout represents a shaft
# clearance only; motor housing and pinion are placement placeholders.
az_mount = box(102, 90, 13, 120, -165, -6.5)
az_mount = az_mount.cut(cyl_z(19, -14, 15, 120, -165))
az_mount = bores_z(az_mount, az_mount_holes, 4.5, -14, 15)
add("26_az_motor_mount", "Azimuth motor mounting bracket", az_mount,
    "mount", notes="Underside mounting plate; four Ø9 holes; motor interface provisional.")

az_motor = cyl_z(P["az_motor_envelope_diameter"] / 2, -77, 62, 120, -165)
add("27_az_motor_envelope", "Azimuth drive motor envelope", az_motor,
    "placeholder", status="placeholder envelope",
    notes="Motor size/torque and mounting flange not selected.")

pinion = cyl_z(16, 43, 10, 120, -165).union(cyl_z(10, -15, 58, 120, -165))
add("28_az_pinion_blank", "Azimuth pinion blank", pinion,
    "placeholder", status="placeholder envelope",
    notes="Un-toothed gear blank near the az drive ring and Ø20 passage shaft; ratio not defined.")

for n, z0, xc in [(29, 221, -187), (30, 178, -190)]:
    clip = box(7, 18, 13, xc, -64, z0)
    clip = clip.cut(cyl_x(3.3, xc - 5, 10, -64, z0))
    add(f"{n:02d}_left_cable_clip", f"Left-arm cable clip {n - 28}", clip,
        "fastener_detail", notes="Simplified small bracket; cable bend radius not assessed.")

# New assembly-specific interface: a separate hub joins the hollow azimuth
# shaft and the rotating turntable. Key/clamp/torque connection is not sized.
az_hub = ring_z(75, 37.1, 41, 12)
az_hub = bores_z(az_hub, bolt_circle_xy(60, 6), 4.0, 40, 14)
add("31_az_shaft_hub", "Azimuth shaft-to-turntable hub blank", az_hub,
    "shaft", notes="Six Ø8 holes match turntable; key, clamp, shaft retention and torque capacity pending.")


def export_assembly():
    assembly = cq.Assembly(name="IMAGE_DERIVED_GIMBAL_CONCEPT")
    for c in COMPONENTS:
        assembly.add(c["local"], name=c["key"],
                     loc=cq.Location(cq.Vector(*c["origin_mm"])),
                     color=cq.Color(*COLORS[c["family"]]))
    assembly.save(str(ROOT / "Gimbal_Assembly.step"), exportType="STEP",
                  mode="default", tolerance=0.1)


def metadata():
    fields = ["item", "step_file", "part_name", "category", "status", "local_origin_in_assembly_mm",
              "bounding_size_mm", "volume_mm3", "notes"]
    with (ROOT / "Parts_List.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for i, c in enumerate(COMPONENTS, 1):
            writer.writerow(dict(item=i, step_file=c["step"].name,
                                 part_name=c["label"], category=c["family"],
                                 status=c["status"],
                                 local_origin_in_assembly_mm=";".join(f"{v:.2f}" for v in c["origin_mm"]),
                                 bounding_size_mm=";".join(f"{v:.2f}" for v in c["bbox_mm"]),
                                 volume_mm3=f"{c['volume_mm3']:.2f}", notes=c["notes"]))
    (ROOT / "parameters.json").write_text(json.dumps(P, indent=2))
    rows = [{k: c[k] for k in ("key", "label", "family", "status", "notes", "origin_mm", "bbox_mm", "volume_mm3")}
            for c in COMPONENTS]
    (ROOT / "assembly_manifest.json").write_text(json.dumps({"parameters": P, "parts": rows}, indent=2))


export_assembly()
metadata()
print(f"Exported {len(COMPONENTS)} STEP parts and one STEP assembly to {ROOT}")
