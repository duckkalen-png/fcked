# Two-axis fork gimbal: image-derived CAD concept

This is a **provisional 31-part model** based on the single perspective image in the conversation. It is useful for reviewing the part breakdown and editing the overall proportions. The image supplies no scale, cross sections, bearing selections, or interface drawings, so the dimensions in this package are assumptions in millimetres. This revision aligns the base housing, turntable, drive ring and deck hole patterns and adds a separate azimuth shaft hub.

## Open in Solid Edge

1. Open `Gimbal_Assembly.step` to review the named, positioned parts together.
2. Open an individual file from `parts_step/` to edit or use it as a separate part. The individual files have a local origin near each part; the assembly STEP applies their placements.
3. Save an opened STEP part as a native Solid Edge `.par` file in Solid Edge. Save the imported assembly as `.asm` if desired. Native `.par` export requires Solid Edge and is unavailable in this workspace.

`Gimbal_Review.FCStd` is a second, grouped review assembly for FreeCAD. `Parts_List.csv` names every part and lists its assumed role and assembly origin. `Base_Subassembly.step` contains only the base mechanism parts. `Base_Assembly_Guide.pdf` shows their fit-up order and known limits. The dark translucent items in the previews represent **equipment envelopes**, not designed motor, camera, telescope, or bearing internals.

## Model structure

| Items | Model group |
| --- | --- |
| 01–07 | Fixed base plate, azimuth bearing and drive blanks, hollow azimuth shaft, rotating turntable and rectangular deck |
| 08–11 | Separately modeled left and right tapered fork arms and inner gussets |
| 12–17 | Left/right altitude bearing cartridges, hollow trunnions and cylindrical spacers between the arms and telescope |
| 18 | Telescope body envelope |
| 19–22 | Nasmyth-side camera adapter, derotator envelope, interface plate and camera envelope |
| 23–25 | Altitude motor mount, coupling envelope and motor envelope |
| 26–28 | Azimuth motor bracket, motor envelope and plain pinion blank |
| 29–30 | Two left-arm cable clip brackets |
| 31 | Separate hollow azimuth shaft-to-turntable hub blank |

The coordinate origin is the middle of the **underside of the fixed circular base plate**. `Z` is the vertical azimuth axis. `X` is the altitude/trunnion axis; the camera is on negative X, altitude motor on positive X. `Y` is front/back. The altitude axis is at Z = 352 mm in the provisional model.

## Main assumptions

- Base plate outer diameter **500 mm**, thickness **18 mm**; 12 illustrative Ø9 holes on Ø460 pitch circle.
- Rotating deck **378 × 250 × 42 mm**; top face Z = 110 mm.
- Fork arm axes at X = ±154 mm; altitude bearing bore Ø82 mm.
- Trunnions Ø60 mm outside, Ø34 mm hollow; cylindrical spacers connect the payload-side gap to the bearing region.
- Telescope envelope 170 × 155 × 120 mm, centered on the altitude axis.
- Motor, camera, derotator, bearing races and gears have envelope geometry only. The azimuth ring and pinion blanks have no teeth.
- Fork gussets represent separate strengthening pieces. Their actual weld/bolt attachment requires detail design.
- Mounting patterns, clearances and fits are illustrative and must be replaced after selecting real components.

The corrected hole patterns are still provisional. The bearing annulus, pinion and drive ring are simplified envelopes. The shaft-to-hub torque connection, fasteners, preload and bearing fits remain unspecified. No load cases, material properties, stiffness, flexure, backlash, optical balance, cable loop, bearing life, motor torque, manufacturing method, or thermal performance have been validated. The central axis passing through the telescope envelope does not prove that it passes through the mass center of a real telescope plus camera.

## Revise the model

`build_gimbal.py` is the editable CadQuery source. Change the `P` values near its top and, where necessary, the profile and interface details in the geometry sections. Then run:

```bash
python3 build_gimbal.py
python3 build_base_subassembly.py
PYTHONPATH=/usr/lib/freecad-python3/lib /usr/bin/python3 make_freecad.py
PYTHONPATH=/usr/lib/freecad-python3/lib /usr/bin/python3 make_freecad.py base
MPLCONFIGDIR=.mplconfig python3 render_preview.py
MPLCONFIGDIR=.mplconfig python3 render_base_section.py
MPLCONFIGDIR=.mplconfig python3 render_base.py
```

`parameters.json` records the last generated assumption set; it is an output reference, not the input to the script. `assembly_manifest.json` records the last generated part origins and bounding sizes.

## Values needed for a dimensioned engineering revision

See `Dimensions_To_Confirm.md`. The first useful inputs are the real base diameter (or another known image scale), telescope mass and center of gravity, required fork spacing and altitude-axis height, and the chosen motor and bearing models. Those inputs determine the most consequential changes to the part geometries.
