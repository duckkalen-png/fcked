"""Create a reviewable base-only STEP assembly and fit-up guide from the full CAD.

Run after build_gimbal.py: python3 build_base_subassembly.py
"""
from pathlib import Path
import csv
import json

import cadquery as cq

ROOT=Path(__file__).resolve().parent
meta=json.loads((ROOT/'assembly_manifest.json').read_text())

KEYS=[
 '01_fixed_base_plate',
 '02_az_bearing_housing',
 '03_az_bearing_envelope',
 '04_az_hollow_shaft',
 '31_az_shaft_hub',
 '05_az_drive_ring',
 '06_az_rotating_turntable',
 '07_rotating_base_deck',
 '26_az_motor_mount',
 '27_az_motor_envelope',
 '28_az_pinion_blank',
]
index={p['key']:p for p in meta['parts']}
assert len(index)==len(meta['parts'])
assert all(k in index for k in KEYS)
parts=[index[k] for k in KEYS]
colors={'structure':(.71,.75,.79),'moving_structure':(.61,.67,.73),
        'bearing':(.27,.38,.46),'shaft':(.37,.51,.59),
        'mount':(.80,.65,.37),'placeholder':(.20,.26,.32)}

assembly=cq.Assembly(name='BASE_AND_AZIMUTH_SUBASSEMBLY')
for item in parts:
    shape=cq.importers.importStep(str(ROOT/'parts_step'/(item['key']+'.step'))).val()
    if not shape.isValid():raise ValueError(item['key'])
    assembly.add(shape,name=item['key'],
                 loc=cq.Location(cq.Vector(*item['origin_mm'])),
                 color=cq.Color(*colors[item['family']]))
assembly.save(str(ROOT/'Base_Subassembly.step'),exportType='STEP',
              mode='default',tolerance=.1)

with (ROOT/'Base_Subassembly_BOM.csv').open('w',newline='') as f:
    w=csv.writer(f)
    w.writerow(['assembly_order','part_key','part_name','status','note'])
    for i,item in enumerate(parts,1):
        w.writerow([i,item['key'],item['label'],item['status'],item['notes']])
(ROOT/'base_selected.json').write_text(json.dumps(KEYS,indent=2))

guide='''# Base and azimuth subassembly — virtual fit-up

The new `Base_Subassembly.step` contains eleven separately named parts from the full gimbal. It starts with the fixed circular base and ends at the rotating rectangular deck. `Base_Exploded_View.png` shows the order schematically. This is the **second, interface-aligned concept revision**. Replace the earlier 30-part package with `Gimbal_CAD_v2_With_Base_Assembly.zip` when working on the base.

**Coordinates:** millimetres. Z is the vertical azimuth axis. The underside of the fixed base plate is Z = 0. X runs along the future altitude axis; Y is front/back. The azimuth motor is at X = 120, Y = −165 mm.

## Parts included

| Stage | Part numbers | Purpose |
| --- | --- | --- |
| Fixed support | 01, 02, 03 | Base plate, housing and provisional bearing annulus |
| Rotating stack | 04, 31, 05, 06, 07 | Hollow shaft, separate hub, drive ring, turntable and fork deck |
| Drive | 26, 27, 28 | Azimuth motor bracket, motor envelope and plain pinion blank |

## Suggested assembly order

1. **Orient and anchor part 01.** The Ø500 × 18 base plate has twelve Ø9 foundation holes on an assumed Ø460 pitch circle. Its central Ø76 passage provides clearance for the vertical shaft envelope. Confirm the actual foundation pattern before drilling anything.
2. **Fit part 02 to part 01.** Eight Ø10 holes on an assumed Ø350 pitch circle now align between the azimuth bearing housing and the fixed plate. The housing spans Z = 18–40 mm. Fastener type, seating face and torque remain to be specified.
3. **Place part 03 in the housing.** Its Ø310 outer envelope meets the housing's nominal Ø310 seat and extends to the underside of the turntable at Z = 53 mm. This is a *space claim*, not a selected rolling-element bearing. The actual bearing determines fit, retention, preload and life.
4. **Prepare the rotating stack.** Part 04 is the hollow vertical shaft. Part 31 is a separate hub blank below the turntable (Z = 41–53). Its six Ø8 holes on Ø120 PCD match part 06. The shaft-to-hub key, clamp or other torque connection is not yet defined.
5. **Join the drive ring and turntable.** Part 05 meets the underside of part 06 at Z = 53 mm. Their eight Ø10 holes on Ø348 PCD align. The ring is a smooth blank; the eventual gear/tooth design may alter its radius and attachment.
6. **Seat the rotating stack on the bearing.** Part 06 meets the upper bearing envelope at Z = 53 mm. Check the vertical axis, the chosen bearing's axial/radial retention and clearance, and the moving parts' free rotation after actual bearing data are available.
7. **Attach the deck.** Part 07 sits on part 06 at Z = 68 mm. Four Ø9 holes at X = ±130, Y = ±90 mm align between these parts. Its top is Z = 110 mm; the next region will attach the fork feet at X = ±154, Y = ±55 mm.
8. **Add the underside motor group.** Part 26 meets the underside of the fixed plate. Its four Ø9 holes align with four fixed-plate holes. Part 27 occupies the motor volume; part 28 passes through the Ø24 drive-shaft opening. These are envelopes pending an actual gearbox and shaft interface.
9. **Check motion and records.** In the CAD model, inspect radial clearance between the fixed bearing housing and the rotating drive ring, check that hole patterns remain aligned, and record the bearing, gear, fastener and motor choices before physical assembly.

## What the fit-up establishes

- The housing-to-base, ring-to-turntable, hub-to-turntable, turntable-to-deck and motor-bracket-to-base hole centers are now matched in the exported solids.
- The bearing annulus reaches the turntable underside, and the nominal bearing/housing diameters meet.
- The ring and pinion are **unt​​oothed blanks** with a deliberate gap; gear mesh has not been designed or validated.
- Individual STEP parts and `Base_Subassembly.step` were re-imported and checked as valid solids/assembly entities.

## Dimensions required before a physical build

Select the azimuth bearing and supply its OD, ID, width, loads and mounting instructions; the azimuth motor/gearbox and output shaft; the drive ratio and backlash requirement; the mass and center of gravity of the complete rotating assembly; foundation bolt pattern; materials, joining method, environmental and pointing requirements. These determine fits, fastener lengths and grades, preload, torque, hub/key design, stiffness and safety margins. None can be set reliably from the reference image alone.
'''
guide=guide.replace('\u200b','')
(ROOT/'Base_Assembly_Guide.md').write_text(guide)
print('Base-only assembly:',len(parts),'named parts')
