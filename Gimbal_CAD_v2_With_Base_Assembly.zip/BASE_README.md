# Base and azimuth drive subassembly

Start with `Base_Assembly_Guide.pdf`. The labeled axial section shows how the base parts stack; the exploded view shows their suggested order.

Open `Base_Subassembly.step` in Solid Edge to inspect the eleven positioned components. The `parts_step/` folder contains those eleven as separate STEP parts that you can open and save as native `.par` files. `Base_Subassembly.FCStd` is a grouped FreeCAD review copy. `Base_Subassembly_BOM.csv` lists the pieces in assembly order.

The base is a provisional **500 mm diameter** concept in millimetres. This second revision aligns the housing, drive ring, hub, turntable and deck bolt patterns. The bearing, motor, pinion and gear ring still need real vendor parts and engineering details. The guide documents the remaining bearing fits, shaft/hub torque connection, gear teeth, fasteners and drive data.

When you are ready to add the fork, use `Gimbal_CAD_v2_With_Base_Assembly.zip`. Its fork feet are positioned at X = ±154 mm, Y = ±55 mm on the deck. Use `Dimensions_To_Confirm.md` to replace provisional dimensions with your project's values.
